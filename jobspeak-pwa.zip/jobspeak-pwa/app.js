// ── JobSpeak App Logic ──

let currentScreen = 'home';
let cardIndex = 0;
let cardFlipped = false;
let cardDeck = [];
let quizIndex = 0;
let quizScore = 0;
let quizAnswered = false;
let aiTurn = 0;
let activeCareerFilter = 'all';
let deferredPrompt = null;

// ── Init ──
document.addEventListener('DOMContentLoaded', () => {
  updateClock();
  setInterval(updateClock, 1000);
  renderHomeCareers();
  renderCareersGrid(window.CAREERS);
  loadFlashcardDeck('aviation');
  loadScenario('mayday');
  renderQuizQuestion();
  registerServiceWorker();
  listenForInstall();
});

function updateClock() {
  const now = new Date();
  const h = now.getHours().toString().padStart(2,'0');
  const m = now.getMinutes().toString().padStart(2,'0');
  document.querySelectorAll('.sb-time').forEach(el => el.textContent = `${h}:${m}`);
}

// ── Service Worker ──
function registerServiceWorker() {
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/sw.js').catch(() => {});
  }
}

function listenForInstall() {
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e;
    setTimeout(showInstallBanner, 3000);
  });
}

function showInstallBanner() {
  const existing = document.getElementById('install-banner');
  if (existing) return;
  const banner = document.createElement('div');
  banner.id = 'install-banner';
  banner.className = 'install-banner';
  banner.innerHTML = `
    <span style="font-size:24px">📱</span>
    <div class="ib-text">
      <strong>Add to Home Screen</strong>
      Install JobSpeak for offline access
    </div>
    <button class="ib-btn" onclick="installApp()">Install</button>
    <span class="ib-close" onclick="dismissInstall()">×</span>
  `;
  document.getElementById('app').appendChild(banner);
}

function installApp() {
  if (deferredPrompt) {
    deferredPrompt.prompt();
    deferredPrompt.userChoice.then(() => { deferredPrompt = null; });
  }
  dismissInstall();
}

function dismissInstall() {
  const b = document.getElementById('install-banner');
  if (b) b.remove();
}

// ── Navigation ──
function goTo(screen) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById('screen-' + screen).classList.add('active');
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('on'));
  const navEl = document.querySelector(`.nav-item[data-screen="${screen}"]`);
  if (navEl) navEl.classList.add('on');
  currentScreen = screen;
}

// ── HOME ──
function renderHomeCareers() {
  const enrolled = window.CAREERS.filter(c => c.enrolled || c.p > 0).slice(0, 6);
  const container = document.getElementById('home-careers');
  container.innerHTML = enrolled.map(c => `
    <div class="career-mini ${c.enrolled?'enrolled':''}" onclick="goTo('careers')">
      <div class="career-mini-bar" style="background:${c.col}"></div>
      <span class="cm-emoji">${c.e}</span>
      <div class="cm-name">${c.n}</div>
      <div class="cm-count">${c.t} terms</div>
      <div class="cm-prog"><div class="cm-fill" style="width:${c.p}%;background:${c.col}"></div></div>
    </div>
  `).join('');
}

// ── CAREERS ──
function renderCareersGrid(list) {
  const g = document.getElementById('careers-grid-main');
  g.innerHTML = list.map(c => `
    <div class="career-tile ${c.enrolled?'enrolled':''}">
      <div class="ct-bar" style="background:${c.col}"></div>
      ${c.niche ? '<span class="ct-niche">Niche</span>' : ''}
      <span class="ct-emoji">${c.e}</span>
      <div class="ct-name">${c.n}</div>
      <div class="ct-count">${c.t} terms</div>
      <div class="ct-prog"><div class="ct-fill" style="width:${c.p}%;background:${c.col}"></div></div>
    </div>
  `).join('');
}

function setCareerFilter(f, el) {
  activeCareerFilter = f;
  document.querySelectorAll('.filter-pill').forEach(p => p.classList.remove('on'));
  el.classList.add('on');
  applyCareerFilter();
}

function applyCareerFilter() {
  const q = (document.getElementById('career-search')?.value || '').toLowerCase();
  let list = window.CAREERS;
  if (activeCareerFilter !== 'all') {
    list = list.filter(c => c.c === activeCareerFilter || (activeCareerFilter === 'niche' && c.niche));
  }
  if (q) list = list.filter(c => c.n.toLowerCase().includes(q));
  renderCareersGrid(list);
}

// ── FLASHCARD ──
function loadFlashcardDeck(career) {
  cardDeck = window.FLASHCARDS[career] || window.FLASHCARDS.aviation;
  cardIndex = 0;
  cardFlipped = false;
  renderCard();
}

function renderCard() {
  if (!cardDeck.length) return;
  const c = cardDeck[cardIndex];
  document.getElementById('c-tag').textContent = c.tag;
  document.getElementById('c-word').textContent = c.w;
  document.getElementById('c-phon').textContent = c.p;
  document.getElementById('c-hint').textContent = c.hint;
  document.getElementById('c-def').textContent = c.def;
  document.getElementById('c-ex').textContent = c.ex;
  document.getElementById('fc-count').textContent = `${cardIndex + 1} / ${cardDeck.length}`;
  document.getElementById('fc-progress').style.width = `${((cardIndex + 1) / cardDeck.length) * 100}%`;
  document.getElementById('pron-score-val').textContent = '—';
  cardFlipped = false;
  document.getElementById('flip-inner').classList.remove('flipped');
  document.querySelectorAll('.p-bar').forEach(b => b.classList.remove('active'));
}

function flipCard() {
  cardFlipped = !cardFlipped;
  document.getElementById('flip-inner').classList.toggle('flipped', cardFlipped);
}

function rateCard(rating) {
  cardIndex = (cardIndex + 1) % cardDeck.length;
  renderCard();
}

function simulatePronunciation() {
  const btn = document.getElementById('pron-record-btn');
  btn.textContent = '⏳ Analysing…';
  btn.style.opacity = '0.6';
  btn.disabled = true;
  let t = 0;
  const iv = setInterval(() => {
    document.querySelectorAll('.p-bar').forEach(b => {
      b.style.height = (15 + Math.random() * 85) + '%';
      b.classList.add('active');
    });
    t++;
    if (t > 8) {
      clearInterval(iv);
      const score = 70 + Math.floor(Math.random() * 24);
      const el = document.getElementById('pron-score-val');
      el.textContent = score + '/100';
      el.style.color = score >= 88 ? 'var(--teal)' : score >= 72 ? 'var(--amber)' : 'var(--rust)';
      btn.textContent = '🎙️ Record Again';
      btn.style.opacity = '1';
      btn.disabled = false;
    }
  }, 130);
}

// ── SCENARIO ──
function loadScenario(key) {
  const s = window.SCENARIOS[key];
  if (!s) return;
  document.getElementById('scene-badge').textContent = s.career;
  document.getElementById('scene-title').textContent = s.title;
  document.getElementById('scene-desc').textContent = s.desc;

  const tags = document.getElementById('scene-tags');
  tags.innerHTML = s.tags.map(t => `<span class="s-tag">${t}</span>`).join('');

  const dlg = document.getElementById('dialogue-area');
  dlg.innerHTML = `
    <div class="msg-row">
      <div class="msg-av" style="background:var(--indigo-l)">${s.opening.speaker}</div>
      <div class="bubble b-sys">"${s.opening.text}"</div>
    </div>
    <div class="msg-row">
      <div class="msg-av" style="background:var(--amber-l)">⁉️</div>
      <div class="bubble b-sys" style="background:var(--amber-l);font-size:12px;font-style:italic">Your turn — select a response below ↓</div>
    </div>
  `;

  const choicesEl = document.getElementById('choices-container');
  choicesEl.innerHTML = s.choices.map((ch, i) =>
    `<button class="choice-btn" onclick="pickScenarioChoice(this, ${ch.correct}, '${key}')">${ch.text}</button>`
  ).join('');

  const phrasesEl = document.getElementById('phrases-list');
  phrasesEl.innerHTML = s.phrases.map(p =>
    `<div class="phrase-row"><span class="phrase-term">${p.term}</span><span class="phrase-def">${p.def}</span></div>`
  ).join('');
}

function pickScenarioChoice(btn, correct, key) {
  const s = window.SCENARIOS[key];
  document.querySelectorAll('.choice-btn').forEach(b => b.classList.remove('correct', 'wrong'));
  btn.classList.add(correct ? 'correct' : 'wrong');
  if (!correct) {
    const correctBtn = [...document.querySelectorAll('.choice-btn')].find((b, i) =>
      window.SCENARIOS[key].choices[i]?.correct
    );
    if (correctBtn) correctBtn.classList.add('correct');
  }
  const dlg = document.getElementById('dialogue-area');
  const fb = document.createElement('div');
  fb.className = 'msg-row';
  fb.innerHTML = `
    <div class="msg-av" style="background:var(--teal-l)">🤖</div>
    <div class="bubble b-sys">${correct ? s.correctFeedback : s.wrongFeedback}</div>
  `;
  dlg.appendChild(fb);
  dlg.scrollTop = dlg.scrollHeight;
}

// ── QUIZ ──
function renderQuizQuestion() {
  const qs = window.QUIZ_QUESTIONS;
  const q = qs[quizIndex % qs.length];
  document.getElementById('q-num').textContent = quizIndex + 1;
  document.getElementById('q-total').textContent = qs.length;
  document.getElementById('qp-fill').style.width = `${((quizIndex + 1) / qs.length) * 100}%`;
  document.getElementById('q-type-badge').textContent = q.type;
  document.getElementById('q-type-badge').className = 'qt-badge ' + (q.type === 'Fill in Blank' ? 'qt-fill' : 'qt-mcq');
  document.getElementById('q-career-tag').textContent = q.career;
  document.getElementById('q-text').textContent = q.q;
  document.getElementById('q-ctx').textContent = q.ctx;
  document.getElementById('q-score').textContent = `✓ ${quizScore} correct`;
  document.getElementById('exp-box').classList.remove('show');
  document.getElementById('next-q-btn').classList.remove('show');
  quizAnswered = false;

  const grid = document.getElementById('answers-grid');
  grid.innerHTML = q.ans.map((a, i) =>
    `<button class="ans-btn" onclick="pickAnswer(this, ${i === q.c})">${a}</button>`
  ).join('');
}

function pickAnswer(btn, correct) {
  if (quizAnswered) return;
  quizAnswered = true;
  const q = window.QUIZ_QUESTIONS[quizIndex % window.QUIZ_QUESTIONS.length];
  document.querySelectorAll('.ans-btn').forEach((b, i) => {
    b.classList.remove('correct', 'wrong');
    if (i === q.c) b.classList.add('correct');
  });
  if (!correct) btn.classList.add('wrong');
  else quizScore++;
  document.getElementById('exp-text').textContent = q.exp;
  document.getElementById('exp-box').classList.add('show');
  document.getElementById('next-q-btn').classList.add('show');
  document.getElementById('q-score').textContent = `✓ ${quizScore} correct`;
}

function nextQuestion() {
  quizIndex++;
  if (quizIndex >= window.QUIZ_QUESTIONS.length) {
    quizIndex = 0; quizScore = 0;
  }
  renderQuizQuestion();
}

// ── AI COACH ──

// Your Anthropic API key — set this in the Netlify dashboard as an environment
// variable called ANTHROPIC_API_KEY, or paste it directly here for testing.
// ⚠️  Never share your key publicly.
const ANTHROPIC_API_KEY = window.ANTHROPIC_API_KEY || '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';

// Full conversation history sent to Claude on every turn so it remembers context
let chatHistory = [];
let activeCareer = 'Aviation';

// The system prompt that turns Claude into a professional English coach
function buildSystemPrompt(career) {
  return `You are Coach Alex, an expert ${career} English coach inside the JobSpeak app.

Your job is to help non-native English speakers master professional ${career} English through conversation practice.

Rules:
- Stay in character as a friendly, encouraging, expert coach
- Keep responses concise and mobile-friendly (max 4 short paragraphs)
- Always give specific, actionable feedback on the user's English
- Highlight any grammar mistakes gently using ✏️ and show the correction
- Rate responses on professionalism, vocabulary, and accuracy
- At the end of each response include a score like: "Score: 87/100 ⚡+45 XP"
- Use relevant ${career} terminology and scenarios
- If the user is doing well, increase the difficulty of the scenario
- Format feedback with short lines — this is a mobile app
- Use emojis sparingly but effectively to make feedback clear

Start by setting up a realistic ${career} workplace scenario and asking the user to respond.`;
}

function handleChatKey(e) {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
}

async function sendMessage() {
  const input = document.getElementById('chat-input');
  const msg = input.value.trim();
  if (!msg) return;

  // Disable input while waiting
  input.disabled = true;
  document.querySelector('.send-btn').disabled = true;

  appendChatMsg(msg, true);
  input.value = '';

  // Add user message to history
  chatHistory.push({ role: 'user', content: msg });

  const typing = appendTyping();

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
        'anthropic-dangerous-direct-browser-access': 'true'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1024,
        system: buildSystemPrompt(activeCareer),
        messages: chatHistory
      })
    });

    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      throw new Error(err.error?.message || `API error ${response.status}`);
    }

    const data = await response.json();
    const replyText = data.content?.[0]?.text || 'Sorry, I could not generate a response.';

    // Add assistant reply to history for context
    chatHistory.push({ role: 'assistant', content: replyText });

    typing.remove();
    appendAiReply(replyText);

  } catch (err) {
    typing.remove();
    let errorMsg = '⚠️ Could not reach the AI coach.';
    if (ANTHROPIC_API_KEY === 'YOUR_API_KEY_HERE') {
      errorMsg = '🔑 <strong>API key not set.</strong><br>Open <code>app.js</code> and replace <code>YOUR_API_KEY_HERE</code> with your Anthropic API key from <a href="https://console.anthropic.com" target="_blank" style="color:var(--rust)">console.anthropic.com</a>';
    } else if (err.message.includes('401')) {
      errorMsg = '🔑 Invalid API key. Check your key at console.anthropic.com';
    } else if (err.message.includes('429')) {
      errorMsg = '⏳ Rate limit reached. Wait a moment and try again.';
    }
    appendAiReply(errorMsg);
    // Remove the failed user message from history
    chatHistory.pop();
  } finally {
    input.disabled = false;
    document.querySelector('.send-btn').disabled = false;
    input.focus();
  }
}

function appendChatMsg(text, isUser) {
  const wrap = document.getElementById('chat-messages');
  const d = document.createElement('div');
  d.className = 'chat-msg' + (isUser ? ' user' : '');
  d.innerHTML = `
    <div class="c-av ${isUser ? 'u-c-av' : 'ai-c-av'}">${isUser ? '👤' : '🤖'}</div>
    <div class="chat-bubble ${isUser ? 'u-bubble' : 'ai-bubble'}">${text}</div>
  `;
  wrap.appendChild(d);
  wrap.parentElement.scrollTop = wrap.parentElement.scrollHeight;
  return d;
}

function appendAiReply(text) {
  // Convert Score: XX/100 into styled badge
  const styled = text
    .replace(/Score:\s*(\d+)\/100/g, '<span class="score-display">$1/100</span>')
    .replace(/⚡\+(\d+)\s*XP/g, '<span class="fb-chip fc-xp">⚡ +$1 XP</span>')
    .replace(/✅([^<\n]+)/g, '<span class="fb-chip fc-good">✅$1</span>')
    .replace(/✏️([^\n]+)/g, '<div style="background:var(--amber-l);color:var(--amber);border-radius:8px;padding:6px 10px;margin-top:6px;font-size:12px">✏️$1</div>')
    .replace(/\n\n/g, '<br><br>')
    .replace(/\n/g, '<br>');

  const wrap = document.getElementById('chat-messages');
  const d = document.createElement('div');
  d.className = 'chat-msg';
  d.innerHTML = `
    <div class="c-av ai-c-av">🤖</div>
    <div class="chat-bubble ai-bubble">${styled}</div>
  `;
  wrap.appendChild(d);
  wrap.parentElement.scrollTop = wrap.parentElement.scrollHeight;
}

function appendTyping() {
  const wrap = document.getElementById('chat-messages');
  const d = document.createElement('div');
  d.className = 'chat-msg';
  d.innerHTML = `<div class="c-av ai-c-av">🤖</div><div class="chat-bubble ai-bubble"><div class="typing-dots"><span></span><span></span><span></span></div></div>`;
  wrap.appendChild(d);
  wrap.parentElement.scrollTop = wrap.parentElement.scrollHeight;
  return d;
}

function selectAiCareer(el, career) {
  document.querySelectorAll('.cc-pill').forEach(p => p.classList.remove('on'));
  el.classList.add('on');
  activeCareer = career;

  // Reset conversation history for new career
  chatHistory = [];

  const wrap = document.getElementById('chat-messages');
  const d = document.createElement('div');
  d.className = 'chat-msg';
  d.innerHTML = `<div class="c-av ai-c-av">🤖</div><div class="chat-bubble ai-bubble">Switching to <strong>${career}</strong> English. I'll set up a new scenario for you — go ahead and respond when ready! 🎭</div>`;
  wrap.appendChild(d);
  wrap.parentElement.scrollTop = wrap.parentElement.scrollHeight;
}
