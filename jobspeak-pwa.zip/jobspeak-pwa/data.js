// ── JobSpeak Data ──

window.CAREERS = [
  {e:'✈️',n:'Airline Pilot',c:'transport',col:'#3d52a0',t:420,p:62,enrolled:true},
  {e:'🗼',n:'ATC Controller',c:'transport',col:'#3d52a0',t:310,p:15,niche:true},
  {e:'🛩️',n:'Flight Dispatcher',c:'transport',col:'#3d52a0',t:280,p:0,niche:true},
  {e:'🚢',n:'Ship Captain',c:'transport',col:'#1a6b8a',t:390,p:5},
  {e:'⚓',n:'Maritime Engineer',c:'transport',col:'#1a6b8a',t:340,p:0},
  {e:'🚁',n:'Helicopter Pilot',c:'transport',col:'#3d52a0',t:260,p:0,niche:true},
  {e:'🛸',n:'Drone Operator',c:'transport',col:'#6b3fa0',t:180,p:0,niche:true},
  {e:'🚂',n:'Train Driver',c:'transport',col:'#1a7a6e',t:190,p:0},
  {e:'👨‍⚕️',n:'Surgeon',c:'health',col:'#d4522a',t:580,p:0},
  {e:'💊',n:'Pharmacist',c:'health',col:'#1a7a6e',t:410,p:0},
  {e:'🚑',n:'Paramedic',c:'health',col:'#d4522a',t:320,p:0},
  {e:'🦷',n:'Dentist',c:'health',col:'#1a7a6e',t:290,p:0},
  {e:'🧬',n:'Genetic Counsellor',c:'health',col:'#6b3fa0',t:340,p:0,niche:true},
  {e:'🏥',n:'ICU Nurse',c:'health',col:'#d4522a',t:360,p:28},
  {e:'🧠',n:'Neurosurgeon',c:'health',col:'#3d52a0',t:480,p:0,niche:true},
  {e:'💻',n:'Software Engineer',c:'tech',col:'#3d52a0',t:520,p:10},
  {e:'🔐',n:'Cybersecurity Analyst',c:'tech',col:'#d4522a',t:440,p:0},
  {e:'🤖',n:'AI / ML Engineer',c:'tech',col:'#6b3fa0',t:380,p:0,niche:true},
  {e:'🎮',n:'Game Developer',c:'tech',col:'#6b3fa0',t:310,p:0,niche:true},
  {e:'☁️',n:'Cloud Architect',c:'tech',col:'#1a6b8a',t:400,p:0,niche:true},
  {e:'📡',n:'Network Engineer',c:'tech',col:'#3d52a0',t:360,p:0},
  {e:'📊',n:'Financial Analyst',c:'finance',col:'#c47c0a',t:460,p:0},
  {e:'🏦',n:'Investment Banker',c:'finance',col:'#c47c0a',t:530,p:0},
  {e:'📉',n:'Hedge Fund Trader',c:'finance',col:'#d4522a',t:410,p:0,niche:true},
  {e:'💹',n:'Forex Trader',c:'finance',col:'#c47c0a',t:300,p:0,niche:true},
  {e:'🏘️',n:'Real Estate Broker',c:'finance',col:'#1a7a6e',t:350,p:0},
  {e:'🧾',n:'Auditor',c:'finance',col:'#1a7a6e',t:380,p:0},
  {e:'⚖️',n:'Corporate Lawyer',c:'legal',col:'#3d52a0',t:590,p:0},
  {e:'🕵️',n:'Paralegal',c:'legal',col:'#3d52a0',t:380,p:0},
  {e:'🔍',n:'Forensic Analyst',c:'legal',col:'#6b3fa0',t:340,p:0,niche:true},
  {e:'📜',n:'Patent Attorney',c:'legal',col:'#3d52a0',t:420,p:0,niche:true},
  {e:'👮',n:'Immigration Officer',c:'legal',col:'#d4522a',t:310,p:0},
  {e:'🔧',n:'Aircraft Mechanic',c:'trades',col:'#c47c0a',t:380,p:0,niche:true},
  {e:'⚡',n:'Electrician',c:'trades',col:'#c47c0a',t:290,p:0},
  {e:'🔩',n:'Mechanical Engineer',c:'trades',col:'#1a7a6e',t:430,p:0},
  {e:'🏗️',n:'Civil Engineer',c:'trades',col:'#1a7a6e',t:400,p:0},
  {e:'🛢️',n:'Oil Rig Engineer',c:'trades',col:'#c47c0a',t:360,p:0},
  {e:'🌊',n:'Offshore Diver',c:'trades',col:'#1a6b8a',t:280,p:0,niche:true},
  {e:'🚒',n:'Firefighter',c:'trades',col:'#d4522a',t:290,p:0},
  {e:'🔬',n:'Research Scientist',c:'science',col:'#6b3fa0',t:490,p:0},
  {e:'🧪',n:'Chemist',c:'science',col:'#1a7a6e',t:420,p:0},
  {e:'🌍',n:'Geologist',c:'science',col:'#c47c0a',t:370,p:0},
  {e:'🔭',n:'Astrophysicist',c:'science',col:'#3d52a0',t:460,p:0,niche:true},
  {e:'🚀',n:'Aerospace Engineer',c:'science',col:'#3d52a0',t:510,p:0,niche:true},
  {e:'🌱',n:'Agronomist',c:'science',col:'#1a7a6e',t:310,p:0},
  {e:'🌡️',n:'Meteorologist',c:'science',col:'#1a6b8a',t:340,p:0,niche:true},
  {e:'🦁',n:'Wildlife Biologist',c:'science',col:'#1a7a6e',t:320,p:0,niche:true},
  {e:'🍷',n:'Sommelier',c:'creative',col:'#d4522a',t:280,p:0,niche:true},
  {e:'🎬',n:'Film Director',c:'creative',col:'#6b3fa0',t:340,p:0},
  {e:'🏨',n:'Hotel Manager',c:'creative',col:'#1a7a6e',t:380,p:0},
  {e:'👨‍🍳',n:'Executive Chef',c:'creative',col:'#c47c0a',t:320,p:0},
  {e:'🧘',n:'Sports Psychologist',c:'creative',col:'#6b3fa0',t:300,p:0,niche:true},
  {e:'🎤',n:'UN Interpreter',c:'creative',col:'#3d52a0',t:460,p:0,niche:true},
  {e:'🎯',n:'Pro Sports Coach',c:'creative',col:'#1a7a6e',t:280,p:0},
  {e:'🔊',n:'Sound Engineer',c:'creative',col:'#6b3fa0',t:260,p:0,niche:true},
  {e:'🏛️',n:'Archaeologist',c:'science',col:'#c47c0a',t:350,p:0,niche:true},
  {e:'🧑‍🚀',n:'Astronaut',c:'science',col:'#3d52a0',t:520,p:0,niche:true},
  {e:'🕶️',n:'Intelligence Analyst',c:'niche',col:'#0d0e12',t:440,p:0,niche:true},
  {e:'🏊',n:'Navy SEAL / Spec Ops',c:'niche',col:'#0d0e12',t:400,p:0,niche:true},
  {e:'🎲',n:'Casino Pit Manager',c:'niche',col:'#c47c0a',t:220,p:0,niche:true},
  {e:'🏺',n:'Art Auction Specialist',c:'niche',col:'#6b3fa0',t:260,p:0,niche:true},
];

window.FLASHCARDS = {
  aviation: [
    {w:'Squawk',p:'/skwɒk/',tag:'✈️ ATC',hint:'Transponder code instruction',def:'To set a specific 4-digit transponder code assigned by ATC to identify an aircraft on radar.',ex:'"Speedbird 492, squawk 2471 and ident."'},
    {w:'Ident',p:'/ˈaɪdent/',tag:'✈️ ATC',hint:'Identity confirmation',def:'A function pilots activate that makes their radar return flash on controller screens.',ex:'"Squawk and ident confirmed — radar contact."'},
    {w:'Wilco',p:'/ˈwɪlkəʊ/',tag:'✈️ Protocol',hint:'Will comply',def:'Short for "will comply." Confirms the pilot will carry out the received instruction.',ex:'"Turn left heading 270." — "Wilco."'},
    {w:'Mayday',p:'/ˈmeɪdeɪ/',tag:'✈️ Emergency',hint:'International distress signal',def:'The international radio distress signal, spoken three times. From French "m\'aidez" (help me).',ex:'"Mayday Mayday Mayday — engine failure, 2,500 feet."'},
    {w:'Final',p:'/ˈfaɪnəl/',tag:'✈️ Approach',hint:'Last leg before landing',def:'The straight section of the approach path aligned with the runway before touchdown.',ex:'"Speedbird 12, report final runway 27L."'},
    {w:'Roger',p:'/ˈrɒdʒə/',tag:'✈️ Protocol',hint:'Message received',def:'Confirms receipt of a message. Does NOT mean agreement or compliance.',ex:'"Descend to 3,000 feet." — "Roger."'},
    {w:'Cleared',p:'/klɪəd/',tag:'✈️ ATC',hint:'Authorization granted',def:'ATC authorization for a specific action — take-off, landing, approach, or route.',ex:'"Speedbird 12, cleared for take-off runway 27L."'},
    {w:'POB',p:'/piː.əʊ.biː/',tag:'✈️ Emergency',hint:'Persons on board',def:'The number of people aboard the aircraft. Required information in any distress call.',ex:'"State your POB." — "Two POB, Speedbird 492."'},
  ],
  medical: [
    {w:'NPO',p:'/en.piː.əʊ/',tag:'⚕️ Pre-op',hint:'Nothing by mouth',def:'Nil Per Os — patient must not eat or drink. Required before surgery to prevent aspiration.',ex:'"Patient is NPO from midnight."'},
    {w:'Triage',p:'/ˈtriːɑːʒ/',tag:'⚕️ Emergency',hint:'Priority assessment',def:'The process of sorting patients by urgency of need to prioritize treatment.',ex:'"Triage the incoming patients — chest pain first."'},
    {w:'Stat',p:'/stæt/',tag:'⚕️ Urgency',hint:'Immediately',def:'From Latin "statim" — immediately. Used to indicate urgency.',ex:'"Get a CBC stat."'},
    {w:'PRN',p:'/piː.ɑː.en/',tag:'⚕️ Medication',hint:'As needed',def:'Pro Re Nata — medication given only when needed, not on a fixed schedule.',ex:'"Paracetamol 500mg PRN for pain."'},
  ],
  finance: [
    {w:'EBITDA',p:'/iːˈbɪtdə/',tag:'💼 Accounting',hint:'Earnings metric',def:'Earnings Before Interest, Taxes, Depreciation and Amortization. Key profitability measure.',ex:'"Our EBITDA margin improved to 24% this quarter."'},
    {w:'Due Diligence',p:'/djuː ˈdɪlɪdʒəns/',tag:'💼 M&A',hint:'Investigation process',def:'A comprehensive investigation of a business before signing a deal or investment.',ex:'"We need 60 days to complete due diligence."'},
    {w:'Liquidity',p:'/lɪˈkwɪdɪti/',tag:'💼 Finance',hint:'Cash availability',def:'How easily assets can be converted to cash without affecting market price.',ex:'"The fund has strong liquidity — $400M in cash."'},
  ],
  legal: [
    {w:'Deposition',p:'/ˌdepəˈzɪʃən/',tag:'⚖️ Litigation',hint:'Out-of-court testimony',def:'Sworn out-of-court testimony given by a witness, recorded for later use in court.',ex:'"The deposition is scheduled for Tuesday."'},
    {w:'Injunction',p:'/ɪnˈdʒʌŋkʃən/',tag:'⚖️ Court',hint:'Court order to stop action',def:'A court order requiring a party to do or refrain from doing a specific act.',ex:'"We filed for a temporary injunction."'},
    {w:'Indemnify',p:'/ɪnˈdemnɪfaɪ/',tag:'⚖️ Contract',hint:'Protect from liability',def:'To compensate or protect another party against a loss or legal liability.',ex:'"The contractor shall indemnify the client."'},
  ],
};

window.QUIZ_QUESTIONS = [
  {type:'Fill in Blank',career:'✈️ ATC',q:'ATC responds to a pilot ready for departure: "Speedbird 12, _______ runway 27L."',ctx:'London Heathrow · Tower frequency · ICAO phraseology only',ans:['Go ahead on','Cleared for take-off','You may proceed','Taxi and lift off'],c:1,exp:'"Cleared for take-off" is the ICAO-standard authorisation. Non-standard phrases create dangerous runway ambiguity in international airspace.'},
  {type:'Multiple Choice',career:'⚕️ Medical',q:'A nurse tells you "the patient is NPO." What does this mean?',ctx:'Pre-operative assessment · hospital ward',ans:['Not Physically Outpatient','Nothing by mouth','No Procedures Ordered','Normal Pulse Output'],c:1,exp:'NPO = Nil Per Os (Latin). Patient must not eat or drink — typically required before surgery to prevent aspiration.'},
  {type:'Fill in Blank',career:'💼 Finance',q:'The CFO says Q3 shows positive _______, meaning revenues now exceed all fixed costs.',ctx:'Board presentation · investor call',ans:['ROI','EBITDA','CAGR','Operating Leverage'],c:3,exp:'Operating leverage describes how fixed costs amplify profit once revenues exceed breakeven. The other terms are real but don\'t fit this definition.'},
  {type:'Multiple Choice',career:'⚖️ Legal',q:'Opposing counsel says they will file for an injunction. What are they requesting?',ctx:'Pre-trial hearing · civil litigation',ans:['A financial penalty','A court order to stop an action','An appeal of the verdict','A delay in proceedings'],c:1,exp:'An injunction is a court order requiring a party to do or stop doing something. It\'s a powerful tool often used in IP and employment disputes.'},
  {type:'Fill in Blank',career:'✈️ ATC',q:'A pilot activates _______ on the transponder, causing their radar return to flash on the controller\'s screen.',ctx:'Radar identification · ATC handover',ans:['Squawk','Ident','Roger','Final'],c:1,exp:'"Ident" is the transponder function that makes the aircraft\'s radar blip flash briefly, helping controllers confirm identity.'},
  {type:'Multiple Choice',career:'⚕️ Medical',q:'A doctor orders "2mg morphine IV stat." What does "stat" mean?',ctx:'Emergency department · urgent care',ans:['Slowly and carefully','Standard dose','Immediately','Stop after two doses'],c:2,exp:'"Stat" comes from Latin "statim" meaning immediately. It signals the highest urgency in medical communication.'},
];

window.SCENARIOS = {
  mayday: {
    title: 'Emergency MAYDAY Call',
    career: '✈️ Aviation',
    tags: ['Emergency', 'Intermediate'],
    desc: 'You are the pilot-in-command. Your engine has failed 5 miles east of Bristol. Make a proper MAYDAY call using ICAO standard phraseology.',
    opening: {speaker:'🗼', name:'Bristol Approach', text:'Speedbird 492, Bristol Approach. Squawk 7700, state your emergency.'},
    choices: [
      {text:'"OK, we have an engine out, going down, help!"', correct:false},
      {text:'"Mayday Mayday Mayday — Speedbird 492, engine failure, 5 miles east Bristol, descending through 2,500 feet, 2 POB, request immediate vectors to nearest runway."', correct:true},
      {text:'"Roger, we\'ll try to figure this out and call back."', correct:false},
    ],
    correctFeedback: '✅ Perfect ICAO phraseology! All mandatory elements present: Mayday ×3, callsign, emergency type, position, altitude, POB, and request. +60 XP 🎉',
    wrongFeedback: '❌ Non-standard phrasing. In real emergencies this creates fatal confusion. See the correct answer highlighted above.',
    phrases: [
      {term:'Mayday ×3', def:'Opens distress call — must repeat 3 times'},
      {term:'POB', def:'Persons On Board — required info'},
      {term:'Vectors', def:'Heading instructions from ATC'},
      {term:'Squawk 7700', def:'Universal emergency transponder code'},
    ]
  },
  handover: {
    title: 'Surgical Handover',
    career: '⚕️ Medical',
    tags: ['Communication', 'Intermediate'],
    desc: 'You\'re the outgoing surgeon. Hand over care of a post-operative patient to the night team using SBAR structure.',
    opening: {speaker:'👩‍⚕️', name:'Night Registrar', text:'Can you give me a handover for bed 7?'},
    choices: [
      {text:'"Yeah, he had surgery, seems okay, just watch him."', correct:false},
      {text:'"Situation: Mr. Ahmed, 58, post-op laparoscopic cholecystectomy, Day 1. Background: hypertensive, on ramipril. Assessment: stable, mild pain managed with PRN paracetamol. Recommendation: monitor obs hourly, NPO until morning review."', correct:true},
      {text:'"He\'s fine, I\'ll write it in the notes later."', correct:false},
    ],
    correctFeedback: '✅ Excellent SBAR structure! Situation, Background, Assessment, Recommendation — all present. This is exactly what reduces handover errors. +60 XP',
    wrongFeedback: '❌ Insufficient handover. Incomplete handovers are a leading cause of patient harm. Use SBAR structure — see the correct answer.',
    phrases: [
      {term:'SBAR', def:'Situation · Background · Assessment · Recommendation'},
      {term:'Post-op', def:'After surgery'},
      {term:'PRN', def:'As needed (medication)'},
      {term:'NPO', def:'Nothing by mouth'},
    ]
  },
};

window.AI_REPLIES = [
  (msg) => {
    const good = msg.trim().length > 60;
    return {
      text: `${good ? '✅ <strong>Solid attempt!</strong>' : '⚠️ Too brief — expand your response to include all required elements.'}<br><br>${good ? 'You identified the emergency and gave position. Key note: over the Atlantic, always include <strong>lat/long</strong>, <strong>fuel remaining</strong>, and <strong>POB</strong> — SAR teams need all three.' : 'In an oceanic MAYDAY: Mayday ×3 · callsign · nature · position (lat/long) · altitude · fuel · POB · intentions.'}<br><br><span class="fb-chip fc-good">✓ Structure: ${good?'Good':'Needs work'}</span> <span class="fb-chip fc-tip">💡 Add: fuel + POB</span>${good?' <span class="fb-chip fc-xp">+55 XP</span>':''}`,
      score: good ? (74 + Math.floor(Math.random()*18)) : (38 + Math.floor(Math.random()*22))
    };
  },
  (msg) => ({
    text: `Your tone is calm and professional — exactly right under pressure. ✅<br><br>Now ATC has given you a heading. Respond with a proper <strong>readback</strong> and confirm souls on board.<br><br><span class="fb-chip fc-good">✓ Register: Professional</span> <span class="fb-chip fc-xp">+40 XP</span>`,
    score: 82
  }),
  (msg) => ({
    text: `Perfect readback. You're in the top 12% of Aviation learners on JobSpeak this week. 🏆<br><br>Ready for something harder? Try a <strong>cabin depressurisation over the Pacific</strong>, or switch career tracks using the panel.<br><br><span class="fb-chip fc-xp">+35 XP · Level up incoming 🎉</span>`,
    score: 94
  }),
];
